<?php

ob_start();

setcookie('username', '', time() - 60 * 60 );




?>