this is the fist page. 

<br>
<hr>

<?php

echo "Hello World!" ;


?>

<br>
<?php

echo "<a href='second_page.php'>Second Page</a>";


?>

<?php

echo "<a href='form.php'>Registaion</a>";

?>